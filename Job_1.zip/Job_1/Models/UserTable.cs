﻿namespace Job_1.Models
{
    public class UserTable
    {

        public int user_id { get; set; }
        public string? user_name { get; set; }
        public string? user_password { get; set; }
        public string? user_first_name { get; set; }
        public string? user_last_name { get; set; }
        public string? user_email { get; set; }
        public string? user_contact { get; set; }
        public string? user_type { get; set; }
        public string? last_active { get; set; }
        public string? created_at { get; set; }
        public bool? user_status { get; set; }
        public bool? user_active_status { get; set; }




    }
}
